# Issues & Insights Tracker

## Setup Instructions

### Prerequisites
- Docker
- Docker Compose

### Run

```bash
docker-compose up --build
```

- Frontend: http://localhost:3000
- Backend: http://localhost:8000
- DB: PostgreSQL 15 running at port 5432

### Features
- Create & view issues
- Role-based model (base structure ready)
- FastAPI + SvelteKit + Docker