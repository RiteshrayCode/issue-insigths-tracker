from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from app.models import Base, User, Issue, RoleEnum
from app.database import engine, SessionLocal
from pydantic import BaseModel
from typing import List
import uvicorn

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

Base.metadata.create_all(bind=engine)

class IssueCreate(BaseModel):
    title: str
    description: str
    severity: str

class IssueOut(BaseModel):
    id: int
    title: str
    description: str
    severity: str
    status: str

    class Config:
        orm_mode = True

@app.post("/issues", response_model=IssueOut)
def create_issue(issue: IssueCreate):
    db: Session = SessionLocal()
    db_issue = Issue(
        title=issue.title,
        description=issue.description,
        severity=issue.severity,
        status="OPEN",
        reporter_id=1
    )
    db.add(db_issue)
    db.commit()
    db.refresh(db_issue)
    return db_issue

@app.get("/issues", response_model=List[IssueOut])
def get_issues():
    db: Session = SessionLocal()
    return db.query(Issue).all()

@app.get("/")
def read_root():
    return {"message": "Issues & Insights Tracker API"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)